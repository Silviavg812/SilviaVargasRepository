package util

enum class Tipo {
    Tecnologia, Muebles, Ropa, Generica
}